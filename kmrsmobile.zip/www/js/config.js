
var krms_config ={	
	'ApiUrl' : "http://www.patraer.com/mobileapp/api",
	'DialogDefaultTitle' : "Delivery de Cerveza",
	'pushNotificationSenderid' : "409670212325",
	'facebookAppId' : "YOUR_FACEBOOK_APP_ID",
	'APIHasKey' : "AIzaSyBalxsA6MhAHp8O3241vd6hR75GNI8AN-Y"
};